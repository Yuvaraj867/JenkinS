import { expect, Locator, Page } from "@playwright/test";
import exp from "constants";

export class GenericMethod {
    page:Page;

    constructor(page:Page){
        this.page = page;
    }

    async NavigatTo(url: string): Promise<void>{
        await this.page.goto(url, {waitUntil:"networkidle"});
        console.log(`Navigated to ${url}`);
        await this.page.waitForLoadState("domcontentloaded");
        await this.page.title();

    }
    async waitForElement(locator:Locator):Promise<void>{
        await expect(locator).toBeVisible({timeout: 30000});
    }

    async clickon(locator : Locator): Promise<void>{
        await locator.scrollIntoViewIfNeeded();
        await this.waitForElement(locator);
        await locator.click();
    }

    async enterDetail(locator :Locator, input : string): Promise<void>{
        await locator.click();
        await locator.fill("");
        await locator.fill(input);
    }

    async selectDropdown(locator: Locator, option: string): Promise<void> {
        await this.waitForElement(locator); 
        await locator.click();
        
        const optionLocator = this.page.getByRole('option', { name: option });
        
        await optionLocator.click();
    
        console.log(`Selected Option: ${option}`);
    }

    async selectYear( Year:string) : Promise<void>{
       
        const locator = this.page.getByRole('button', { name: 'Choose date', exact: true });

        await this.waitForElement(locator);
        await locator.click();
        const selectdate = this.page.getByRole('radio', { name: Year });
        await selectdate.click();

        console.log(`Selected Year: ${Year}` );


    }
     async selectDateandTime(Date:string): Promise<void>{
        const clickDatepicker = this.page.locator("//label[text()='Date & Time of Incident']//following::button[@type='button'][1]");
        await clickDatepicker.click();

        const selectDate = this.page.getByRole('gridcell', { name: Date, exact: true });
        await selectDate.click();

        const selecthour = this.page.locator('.MuiClock-squareMask');
       await selecthour.click();

        const selecttime = this.page.locator('.MuiClock-squareMask');
        await selecttime.click();

    }
    
 

    
    async clearElement(locator:Locator){
        await locator.clear();
    }

    async hoverTo(locator:Locator): Promise<void>{
      //  await this.page.hover(locator);
    }

    async waitForElementToDisappear(locator : Locator) : Promise<void>{
        await this.waitForElement(locator);
        await locator.waitFor({state : "detached", timeout:3000})
    }

    async isElementVisible(locator:Locator): Promise<boolean> {
        return await locator.isVisible();

    }

async checkURL(url : string): Promise<void>{
    await expect(this.page).toHaveURL(url);
}

    async uploadFile( path:string): Promise<void>{
        const fileInput = this.page.locator('input[type="file"]').first();
        await fileInput.setInputFiles(path);

    }

    async downloadFile(locator:Locator , path:string ): Promise<void>{
        const downloadPromise = this.page.waitForEvent('download');
        await locator.click();
        const download = await downloadPromise;

        await download.saveAs(path + download.suggestedFilename());
        console.log("downloaded path: " +path);
    }
    
    async draganddrop(from: Locator, to:Locator): Promise<void>{
        await from.dragTo(to);
    }

    async handleAlert(page: Page): Promise<void>{
        page.on("dialog", async (dialog) =>{
            await dialog.accept();
            console.log(dialog);
        });
    }
        async selectCheckBox(locator:Locator):Promise<void>{
            await locator.check();

        }

        async selecttogglebutton(locator:Locator){

            
            await locator.check();
        }
      
        async selectMultiselectDropdown(locator:Locator, option:string):Promise<void>{
            const optionarray = option.split(",");
            for (const options of optionarray){
                await this.waitForElement(locator);
                await this.clickon(locator);
                const input = this.page.getByRole('listbox').getByRole("option", {name:options});
                await this.clickon(input);
            
            }
        }

    }







