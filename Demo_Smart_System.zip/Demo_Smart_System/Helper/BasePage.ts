import {test as Base} from "@playwright/test";

import { LoginPage } from "../Page_Objects/LoginPage";
import { IncidentPage } from "../Page_Objects/IncidentPage";

type Pages = {
    
    login : LoginPage,
    inc : IncidentPage
};

const test = Base.extend<Pages>({
    
    login: async({page}, use)=>{
        const login = new LoginPage(page);
        await use(login)
    },

    inc: async({page},use)=>{
        const inc = new IncidentPage(page);
        await use(inc)
    }

})
export {test};