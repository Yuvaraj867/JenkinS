import { expect,Locator,Page } from "@playwright/test";
import { GenericMethod } from "../Helper/Generic Method";
import { TIMEOUT } from "dns";

export class LoginPage{
    page:Page;
    generic:GenericMethod;
    readonly UserName : Locator;
    readonly Password : Locator;
    readonly Login : Locator;
    readonly Program: Locator;
    readonly Submit : Locator;
    readonly Logout : Locator;

    constructor(page:Page){
        this.page= page;
        this.generic= new GenericMethod(this.page);
        this.UserName = page.getByRole('textbox', { name: 'Email or User name' });
        this.Password = page.getByRole('textbox', { name: 'Password' });
        this.Login = page.getByRole('button', { name: 'LOGIN' });
        this.Program = page.locator('.css-1xc3v61-indicatorContainer');
        this.Submit = page.getByRole('button', { name: 'SUBMIT' });
        this.Logout = page.getByRole('link', { name: 'logout-icon Logout' });
        

}
async setLoginPage(usname:string,pwds:string, url:string ){
    await this.generic.NavigatTo(url);
    await this.generic.enterDetail(this.UserName,usname);
    await this.generic.enterDetail(this.Password,pwds);  
await this.generic.clickon(this.Login);
}

async selectProgram(program:string){
    await this.generic.selectDropdown(this.Program,program);
}

async selectSubmit(){
    await this.generic.clickon(this.Submit);
}

async selectLogout(){

   await this.generic.clickon(this.Logout);
}
}