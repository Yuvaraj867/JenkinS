import { expect,Locator,Page } from "@playwright/test";
import { GenericMethod } from "../Helper/Generic Method";
import { TIMEOUT } from "dns";

export class IncidentPage{
    page:Page;
    
    generic:GenericMethod;
    readonly incidentArrow : Locator;
    readonly incidentmenu : Locator;
    readonly AddIncident : Locator;
    readonly incidentTypedropdown : Locator;
    readonly Outcomesdropdown : Locator;
    readonly cancelButton : Locator;
    readonly policetoggleButton : Locator;
    readonly policeofficername : Locator;
    readonly TimeCalled : Locator;
    readonly Timearrived : Locator;
    readonly BusinessLocation : Locator;
    readonly Summary : Locator;
    readonly Narrative : Locator;
    readonly Addnew : Locator;
    readonly DeletePart : Locator;
    readonly Partytype : Locator;
    readonly Name : Locator;
    readonly LocationInvolved : Locator;
    readonly LocationDropdown : Locator;
    readonly ReportStatus : Locator;
    readonly SupervisorStatus : Locator;
    readonly color : Locator;
    readonly Persons : Locator;
    readonly PersonClose : Locator;
    readonly Maintenance : Locator;
    readonly MaintenanceClose : Locator;
    readonly Equipment : Locator;
    readonly EquipmentClose : Locator;
    readonly Year : Locator;
    readonly Save : Locator;
    readonly SearchID : Locator;
    readonly EditIcon : Locator;
    readonly PersonDelete : Locator;
    readonly EquipmentDelete : Locator;
    readonly MaintenanceDelete : Locator;
    readonly checkbox : Locator;
    readonly DeleteIcon : Locator;
    readonly DeleteYes : Locator;
    readonly DeleteNo : Locator;
    readonly IncidentNo : Locator;
    readonly Back : Locator;
    readonly AddComment : Locator;



    constructor(page:Page){
        this.page= page;
        this.generic= new GenericMethod(this.page);
        this.incidentArrow=page.locator('div').filter({ hasText: /^Incidents$/ }).nth(2);
        this.incidentmenu=page.getByRole('link', { name: 'sidebarPlusIcon Incidents' });
        this.AddIncident=page.getByRole('button', { name: 'ADD Incident' });
        this.incidentTypedropdown = page.locator('div').filter({ hasText: /^Incident Type\*Incident Type$/ }).locator('svg');
        this.policetoggleButton=page.locator('div').filter({ hasText: /^Police Response$/ }).getByLabel('controlled');
        this.policeofficername=page.getByRole('textbox', { name: 'Police Officer Name' });
        this.BusinessLocation=page.locator('div').filter({ hasText: /^Business LocationBusiness Location$/ }).locator('svg');
        this.Summary=page.locator('.ql-editor').first();
        this. Narrative =page.locator('div:nth-child(3) > .Card_card_content__wpaGy > .incident-editor > .quill > .ql-container > .ql-editor');
        this. Addnew =page.getByRole('img', { name: 'plus', exact: true }).first();
        this. DeletePart =page.getByText('Delete').first();
        this. Partytype =page.locator('div').filter({ hasText: /^Party TypeParty Type$/ }).locator('svg');
        this. Name =page.getByRole('textbox', { name: 'Name', exact: true });
        this. LocationInvolved =page.getByRole('textbox', { name: 'Search for an address...' });
        
        this. ReportStatus =page.locator('div').filter({ hasText: /^Report Completion Status\?CompletedIn progress$/ }).getByLabel('In progress');
        this. SupervisorStatus =page.locator('div').filter({ hasText: /^Supervisor Reviewed Status\?CompletedIn progress$/ }).getByLabel('In progress');
        this. color =page.getByRole('textbox', { name: 'Color' });
       // this. Persons =page.locator('div').filter({ hasText: /^Persons Persons$/ }).locator('svg');
        this.Persons = page.locator("//label[text()='Persons ']//following::div[@class='multiSelect__indicators css-1wy0on6'][1]");
        //this.PersonClose = page.locator("//label[text()='Persons ']//following::div[@class='multiSelect__indicator multiSelect__dropdown-indicator css-1xc3v61-indicatorContainer'][1]")
       this.PersonClose=page.locator('.multiSelect__indicators > div:nth-child(3)').first();
       this.PersonDelete=page.locator("//label[text()='Persons ']//following::div[@class='multiSelect__indicator multiSelect__clear-indicator css-1xc3v61-indicatorContainer'][1]");
        //this. Maintenance =page.locator('div').filter({ hasText: /^Maintenance Maintenance$/ }).locator('svg');
        this.Maintenance=page.locator("//label[text()='Maintenance']//following::div[@class='multiSelect__indicators css-1wy0on6'][1]");
        this.MaintenanceClose = page.locator('div:nth-child(2) > .input-height > .multiSelect__control > .multiSelect__indicators > div:nth-child(3)');
        this.MaintenanceDelete=page.locator("//label[text()='Maintenance']//following::div[@class='multiSelect__indicator multiSelect__clear-indicator css-1xc3v61-indicatorContainer'][1]");
        //this. Equipment =page.locator('div').filter({ hasText: /^Equipment Equipment$/ }).locator('svg');
        this.Equipment=page.locator("//label[text()='Equipment ']//following::div[@class='multiSelect__indicators css-1wy0on6'][1]");
        this.EquipmentClose = page.locator('div:nth-child(3) > .input-height > .multiSelect__control > .multiSelect__indicators > div:nth-child(3)');
        this.EquipmentDelete=page.locator("//label[text()='Equipment ']//following::div[@class='multiSelect__indicator multiSelect__clear-indicator css-1xc3v61-indicatorContainer'][1]");
        this. Save =page.locator("//button[text()='SAVE']");
        this.Outcomesdropdown=page.locator('div').filter({ hasText: /^Outcomes\*Outcomes$/ }).locator('svg');
        this.cancelButton=page.locator("//button[text()='CANCEL']");
        this.Year=page.locator("//label[text()='Year ']//following::button[@aria-label='Choose date']");
        this.SearchID = page.getByRole('textbox', { name: 'Search by Priority/ID/Summary' });
        this.EditIcon=page.locator("//tbody//td[text()='${ID}']//following::img[@title='Edit'][1]");
        this.checkbox=page.locator("//tbody// input[@type='checkbox']");
        this.DeleteIcon = page.locator('.me-3 > img').first();
        this.DeleteYes = page.getByRole('button', { name: 'YES' });
        this.DeleteNo = page.getByRole('button', { name: 'NO' });

        this.IncidentNo=page.locator("//p[text()='incident details']//following-sibling::h5");
        this.Back=page.locator("//img[@alt='left icon']");
        this.AddComment=page.getByText('+ Add Comment');
        
        // 
        }
        

        async clickIncidentMenu(){
            await this.generic.clickon(this.incidentArrow);
            await this.generic.clickon(this.incidentmenu);

        }

        async clickAddIncident(){
            await this.generic.clickon(this.AddIncident);
        }

        async selectIncidentType(incident:string){
            await this.generic.selectDropdown(this.incidentTypedropdown,incident);
            
        }

        async selectOutcomeType(outcome:string){
            await this.generic.selectDropdown(this.Outcomesdropdown,outcome);
        }

        async clickCancelButton(){
            await this.generic.clickon(this.cancelButton);
        }

        async selectfile(filename:string){
            await this.generic.uploadFile(filename);
        }

        async selecttheYear(Year:string){
           // await this.generic.selectYear(Year);
           await this.Year.click();

            const selectdate = this.page.getByRole('radio', { name: Year });
        await selectdate.click();

        console.log(`Selected Year: ${Year}` );
        }

        async selecttheDateandTime(Date:string){
            await this.generic.selectDateandTime(Date);
        }

        async selectPolicetoggle(){
            await this.generic.selecttogglebutton(this.policetoggleButton);
        }

        async enterPoliceOfficer(police:string){
            await this.generic.enterDetail(this.policeofficername,police)
        }

        async selectBusinessLocation(BLocation:string){
            await this.generic.selectDropdown(this.BusinessLocation,BLocation)
        }

        async enterSummary(Summary:string){
            await this.generic.enterDetail(this.Summary,Summary);
        }

        async enterNarrative(Narrative:string){
            await this.generic.enterDetail(this.Narrative,Narrative);
        }

        async clickAdd(){
            await this.generic.clickon(this.Addnew);
        }

        async clickDelete(){
            await this.generic.clickon(this.DeletePart);
        }

        async selectParttype(option:string){
            await this.generic.selectDropdown(this.Partytype,option);
        }

        async enterName(Nm : string){
            await this.generic.enterDetail(this.Name,Nm);
        }

        async enterLocationInvolved(loc:string){
            await this.generic.enterDetail(this.LocationInvolved,loc);
            await this.page.locator("//li[text()='Cheverly, Maryland 20785, United States']").click();
           // await this.page.getByText('locOption').click();
        }

        async selectReportCompletionStatus(){
            await this.generic.clickon(this.ReportStatus);
        }

        async selectSupervisorStatus(){
            await this.generic.clickon(this.SupervisorStatus);
        }

        async entercolor(color : string){
            await this.generic.enterDetail(this.color, color);
        }

        async selectPerson(Person:string){
            const persondel = this.PersonDelete;
            if ( await persondel.isVisible()) {

                await this.generic.clickon(this.PersonDelete);}
                await this.page.waitForLoadState('domcontentloaded');
                await this.Persons.waitFor();
                await expect(this.Persons).toBeVisible();


                await this.generic.selectDropdown(this.Persons, Person);
                await this.generic.clickon(this.PersonClose);
            } 
            

        
            
        

        async selectMaintenance(Maintenance:string){
            const Maintdel = this.MaintenanceDelete;

try {
    if (await Maintdel.isVisible()) {
        await this.generic.clickon(Maintdel);
    }
    
    await this.page.waitForLoadState('domcontentloaded');
                await this.Maintenance.waitFor();
                await expect(this.Maintenance).toBeVisible();
    await this.generic.selectDropdown(this.Maintenance, Maintenance);
    await this.generic.clickon(this.MaintenanceClose);

} catch (error) {
    console.error("Unexpected error occurred:", error);
    throw error;  
}

            //await this.generic.selectDropdown(this.MaintenanceClose,Maintenance);
            //await this.generic.clickon(this.MaintenanceClose);
        }
       
        async selectEquipment(Equipment:string){
            const Equipdel = this.EquipmentDelete;
            if ( await Equipdel.isVisible()) {

                await this.generic.clickon(this.EquipmentDelete);
                await this.page.waitForLoadState('domcontentloaded');
                await this.Equipment.waitFor();
                await expect(this.Equipment).toBeVisible();
                await this.generic.selectDropdown(this.Equipment, Equipment);
                await this.generic.clickon(this.EquipmentClose);
            } 
            else {
                await this.page.waitForLoadState('domcontentloaded');
                await this.Equipment.waitFor();
                await expect(this.Equipment).toBeVisible();
                await this.generic.selectDropdown(this.Equipment, Equipment);
                await this.generic.clickon(this.EquipmentClose);
            }

        


            //await this.generic.selectDropdown(this.EquipmentClose, Equipment);
            //await this.generic.clickon(this.EquipmentClose);
        }

        async enterSearchID(ID:string,IDVerify:string){
            await this.generic.enterDetail(this.SearchID,ID);
            const ID3 =this.page. getByRole('cell', { name: IDVerify });
            expect(ID3).toBeVisible();
            await this.page.waitForLoadState('domcontentloaded');
        }

        async clickEditIcon(edit:string){
            const Edit = this.page.locator(`//tbody//td[text()='${edit}']//following::img[@title='Edit'][1]`)
            await Edit.waitFor();
            await expect(Edit).toBeVisible();
            await this.generic.clickon(Edit);
        }

async clickViewIcon(view:string){
    await this.page.waitForLoadState('domcontentloaded');
            const View = this.page.locator(`//tbody//td[text()='${view}']//following::img[@title='View'][1]`);
            await View.waitFor();
            await expect(View).toBeVisible();
            await this.generic.clickon(View);
            await this.page.waitForLoadState('domcontentloaded');
        }

        async clickDeleteList(Delete12:string){
            const Delete = this.page.locator(`//tbody//tr[1]//td//p[text()='${Delete12}']//following::img[@title='Delete'][1]`);
            await Delete.waitFor();
            await expect(Delete).toBeVisible();
            
            if(await this.generic.isElementVisible(Delete)){
                await this.generic.clickon(Delete);
                await this.generic.clickon(this.DeleteYes);
            }
            else{
            console.log("Delete Button not visible")
            }
            await this.page.waitForLoadState('domcontentloaded');
            
        }

    
async VerifyIncidentNo(IncidentNo:string){
    const AddComment = this.AddComment;
   // expect(AddComment).toBeVisible();
        await this.page.waitForLoadState('domcontentloaded');
       await expect(AddComment).toBeVisible({timeout:50000});
       AddComment.click();
      await this.generic.clickon(this.cancelButton);
        const incidentValue = await this.IncidentNo.textContent();
        console.log('text: ', incidentValue);
        const IncNo = incidentValue?.replace(/\s+/g, ' ').replace('ID ', '').trim();
        expect(IncNo).toContain(IncidentNo);


    }


 
        async selectCheckgrid(ID:string){
            const selectcheck = this.page.locator(`//tbody//td[text()='${ID}']//preceding::input[@type='checkbox'][1]`);
            await selectcheck.waitFor();
            
           await expect(selectcheck).toBeVisible();
           await this.generic.selectCheckBox(selectcheck);
           await expect(selectcheck).toBeChecked();
           await this.page.waitForLoadState('domcontentloaded');

          
        }
        
        async clickDeleteIcon(){
            await this.page.waitForSelector('.me-3 > img', { state: 'visible' });
            if(await this.generic.isElementVisible(this.DeleteIcon)){
                await this.generic.clickon(this.DeleteIcon);
                await this.generic.clickon(this.DeleteNo);
            }
            else{
            console.log("Delete Button not visible")
            }
            
        }

        async clickBack(){
            await this.generic.clickon(this.Back);
        }

        async clickSaveButton(){
            await this.generic.clickon(this.Save);
        }

        
            
    }



