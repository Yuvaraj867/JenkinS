import { expect,Locator,Page } from "@playwright/test";
import { GenericMethod } from "../Helper/Generic Method";
import {IncidentPage} from "../Page_Objects/IncidentPage"
import { TIMEOUT } from "dns";

export class OutcomeTypePage{
    page:Page;
    generic:GenericMethod;
    readonly OutcomeType : Locator;
    readonly AddOutcome : Locator;
    readonly OutcomeTypeField : Locator;
    readonly ActiveCheckBox : Locator;
    readonly EditOutcome : Locator;
    readonly SaveChanges : Locator;
    readonly ViewOutcome : Locator;
    readonly CloseOutcome : Locator;
    readonly Statusradiobutton : Locator;
    readonly SearchOutcome : Locator;



    constructor(page:Page){
        this.page= page;
        this.generic= new GenericMethod(this.page);
        
        this.OutcomeType=page.getByRole('link', { name: 'sidebarPlusIcon Admin:Outcome' });
        this.AddOutcome = page.getByRole('button', { name: 'ADD outcome' });
        this.OutcomeTypeField=page.getByRole('textbox', { name: 'Outcome Type', exact: true });
        this.ActiveCheckBox = page.locator('input[name="is_active"]');
        this.EditOutcome=page.locator("");
        this.SaveChanges=page.getByRole('button', { name: 'SAVE CHANGES' });
        this.SearchOutcome=page.getByRole('textbox', { name: 'Search by Outcome type' });
        





    }


}