import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  // Recording...
  await page.getByRole('row', { name: '1051217 Low Animal Related' }).getByRole('img').nth(1).click();
  await page.locator('.multiSelect__indicator').first().click();
  await page.getByRole('option', { name: 'Other user' }).click();
  await page.locator('.multiSelect__indicators > div:nth-child(3)').first().click();
  await page.locator('div:nth-child(2) > .input-height > .multiSelect__control > .multiSelect__indicators > div:nth-child(3)').click();
  await page.getByRole('option', { name: '(O) (Inspection - Vehicle) Thayathery Road, 670012, Thana, Kannur, Kannur,' }).click();
  await page.locator('div:nth-child(2) > .input-height > .multiSelect__control > .multiSelect__indicators > div:nth-child(3)').click();
  await page.locator('div:nth-child(3) > .input-height > .multiSelect__control > .multiSelect__indicators > .multiSelect__indicator').click();
  await page.getByRole('option', { name: 'Jcjc' }).click();
  await page.locator('div:nth-child(3) > .input-height > .multiSelect__control > .multiSelect__indicators > div:nth-child(3)').click();

  await page.locator('.multiSelect__indicator > .css-8mmkcg').first().click();
  await page.locator('div:nth-child(2) > .input-height > .multiSelect__control > .multiSelect__indicators > div > .css-8mmkcg').first().click();
  await page.locator('div').filter({ hasText: /^Equipment Jcjc$/ }).locator('svg').nth(2).click();
  await page.getByRole('option', { name: 'Chch' }).click();
  await page.getByRole('option', { name: 'testtestone' }).click();
  await page.getByRole('option', { name: 'Gg da -' }).click();
  await page.getByText('Persons PersonsMaintenance').click();
  await page.locator('div:nth-child(2) > .input-height > .multiSelect__control > .multiSelect__indicators > .multiSelect__indicator').click();
  await page.locator('div:nth-child(3) > .input-height > .multiSelect__control > .multiSelect__indicators > div > .css-8mmkcg').first().click();

  await page.getByRole('row', { name: '1051205 Low Issue with Animal' }).getByRole('checkbox').check();
  await page.locator('.me-3 > img').first().click();
  await page.getByRole('button', { name: 'NO' }).click();
  await page.getByRole('img', { name: 'view icon' }).click();
  await page.getByRole('heading', { name: 'ID' }).click();
  await page.getByRole('img', { name: 'left icon' }).click();
  await page.getByRole('row', { name: '1051217 Low Animal Related' }).getByRole('img').nth(3).click();
  await page.getByRole('img', { name: 'left icon' }).click();

  await page.getByRole('row', { name: '1051217 Low Animal Related' }).getByRole('img').first().click();
  await page.getByRole('heading', { name: 'ID' }).click();
  await page.getByRole('img', { name: 'left icon' }).click();
await page.locator('div:nth-child(7) > div > .SidebarContainer_sidebar__menu__item__n2-Mz > .undefined').click();

await page.getByRole('link', { name: 'sidebarPlusIcon Admin:Outcome' }).click();
await page.getByRole('button', { name: 'ADD outcome' }).click();
await page.getByRole('textbox', { name: 'Outcome Type', exact: true }).click();
await page.getByRole('textbox', { name: 'Outcome Type', exact: true }).fill('Test');
await page.locator('input[name="is_active"]').uncheck();
await page.getByRole('button', { name: 'SAVE' }).click();
await page.getByRole('row', { name: 'Test view icon edit icon delete icon history icon', exact: true }).getByRole('img').first().click();
await page.getByRole('heading', { name: 'Test' }).click();
await page.getByRole('button', { name: 'Close' }).click();
await page.getByRole('row', { name: 'Test view icon edit icon delete icon history icon', exact: true }).getByRole('img').nth(1).click();
await page.getByRole('textbox', { name: 'Outcome Type', exact: true }).click();
await page.getByRole('textbox', { name: 'Outcome Type', exact: true }).fill('Test12');
await page.getByRole('button', { name: 'SAVE CHANGES' }).click();
await page.getByRole('row', { name: 'Test12 view icon edit icon' }).getByRole('img').nth(2).click();
await page.getByRole('button', { name: 'NO' }).click();
await page.getByRole('row', { name: 'Test12 view icon edit icon' }).getByRole('img').nth(3).click();
await page.getByRole('img', { name: 'left icon' }).click();
await page.getByRole('textbox', { name: 'Search by Outcome type' }).click();
await page.getByRole('textbox', { name: 'Search by Outcome type' }).fill('Test12');
await page.getByRole('checkbox').nth(1).check();
await page.locator('.me-3 > img').first().click();
await page.getByRole('button', { name: 'NO' }).click();
await page.getByRole('checkbox').nth(2).check();
await page.getByRole('button', { name: 'YES' }).click();
await page.getByRole('img', { name: 'edit icon' }).click();
await page.getByRole('button', { name: 'Close', exact: true }).click();

  
  
});