import { test } from "../../Helper/BasePage";

import fs from "fs";
const filePath = "Test_Data/Demo_Data/Sample.json";  
const filePath1 = "Test_Data/Demo_Data/IncidentData.json";  

const jsonData = JSON.parse(fs.readFileSync(filePath, "utf8"));
const jsonData1 = JSON.parse(fs.readFileSync(filePath1, "utf8"));

test("Incident", async ({ page ,login,inc}) => {
    test.setTimeout(80000);
    await login.setLoginPage(jsonData.Info.User,jsonData.Info.Password,jsonData.Info.URL);
    await login.selectProgram(jsonData.Info.Program);
    await login.selectSubmit();
    await inc.clickIncidentMenu();

    await inc.clickAddIncident();
    await inc.selectIncidentType(jsonData1.Incident.IncidentType);
    await inc.selectOutcomeType(jsonData1.Incident.OutcomeType);
    await inc.selectPolicetoggle();
    await inc.enterPoliceOfficer(jsonData1.Incident.Police);
    await inc.selectBusinessLocation(jsonData1.Incident.BusinessLocation);
    await inc.enterSummary(jsonData1.Incident.Summary);
    await inc.enterNarrative(jsonData1.Incident.Narrative);
    await inc.clickAdd();
    await inc.clickDelete();
    await inc.selectParttype(jsonData1.Incident.Partytype);
    await inc.enterName(jsonData1.Incident.Name);
    await inc.enterLocationInvolved(jsonData1.Incident.LocationInvolved);
    await inc.selectReportCompletionStatus();
    await inc.selectSupervisorStatus();
    await inc.entercolor(jsonData1.Incident.color);
    await inc.selectPerson(jsonData1.Incident.Person);
    await inc.selectMaintenance(jsonData1.Incident.Maintenance);
    await inc.selectEquipment(jsonData1.Incident.Equipment);
    await inc.selectfile(jsonData1.Incident.FileUpload);
    await inc.selecttheYear(jsonData1.Incident.Year);
    await inc.selecttheDateandTime(jsonData1.Incident.Date);
    await inc.clickSaveButton();
    await inc.clickDeleteList(jsonData1.Incident.Summary);
    
    await inc.clickViewIcon(jsonData1.Incident.SearchID);
    await inc.VerifyIncidentNo(jsonData1.Incident.SearchID);
    await inc.clickBack();

    await inc.selectCheckgrid(jsonData1.Incident.SearchID);
    await inc.clickDeleteIcon();

    await inc.enterSearchID(jsonData1.Incident.SearchID,jsonData1.Incident.SearchID);
    await inc.clickEditIcon(jsonData1.Incident.SearchID);
    await inc.enterSummary(jsonData1.Incident.SummaryEdit);
    await inc.enterNarrative(jsonData1.Incident.NarrativeEdit);
    await inc.selectPerson(jsonData1.Incident.PersonEdit);
    await inc.selectMaintenance(jsonData1.Incident.MaintenanceEdit);
    await inc.selectEquipment(jsonData1.Incident.EquipmentEdit);
    await inc.clickSaveButton();

    await login.selectLogout();
    //await page.close();
    
    


});